# Architecture Design

## System Overview

یک اپلیکیشن فرانت‌اند تک‌صفحه‌ای (SPA) با Vite که یک لندینگ معرفی کارگاه چوب را در مسیر `/` رندر می‌کند.
تمام محتوای متنی فارسی و ثابت است؛ هیچ لایهٔ داده، احراز هویت یا API لازم نیست. تنها منطق سمت کلاینت شامل انیمیشن اسکرول‌ریویل، وضعیت هدر/منوی موبایل و اعتبارسنجی فرم مشاوره است.

## Tech Stack

- Vite 5 + React 18 + TypeScript
- Tailwind CSS 3 با توکن‌های HSL سفارشی (سفید گرم/زغالی/برنز) و شادcn/ui به‌عنوان پکیج کامپوننت پایه
- فونت Vazirmatn از Google Fonts (بدون وابستگی npm)
- انیمیشن: CSS transition + `IntersectionObserver` بومی (بدون framer-motion)
- آیکون: SVG درون‌خطی برای فلش دکمه‌ها
- رسانه: تصاویر تولیدشده و میزبانی‌شده روی CDN پروژه

## Module Design
| Module | Responsibility | Key Files |
|--------|---------------|-----------|
| Shell | مسیرها، Providerها و رندر صفحهٔ اصلی | `src/App.tsx`, `src/main.tsx`, `src/pages/Index.tsx` |
| Content | پیکربندی واحد برند، ناوبری، پروژه‌ها و اطلاعات تماس | `src/content/site.ts` |
| Motion | ریویل اسکرول قابل استفادهٔ مجدد با fallback دسترس‌پذیر | `src/components/RevealSection.tsx` |
| Layout blocks | هدر، هیرو، معرفی، شوروم، تماس، فوتر | `src/components/SiteHeader.tsx`, `HeroSection.tsx`, `WelcomeSection.tsx`, `ShowroomSection.tsx`, `ContactSection.tsx`, `SiteFooter.tsx` |
| Primitives | دکمه/لینک فلش‌دار مینیمال | `src/components/ArrowLink.tsx` |
| Theme | متغیرهای رنگ، RTL، کلاس‌های reveal و فیلد فرم | `src/index.css`, `tailwind.config.ts`, `index.html`, `DESIGN.md` |
| Media | تصاویر پروژه | `image_manifest.json`, `/workspace/assets/images/*.png` |

## Tech Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|
| لایهٔ بک‌اند | ندارد (frontend-only) | محتوا ایستا است؛ نیازی به DB/Auth/Edge Function نیست و دامنه را بی‌دلیل بزرگ نمی‌کند |
| انیمیشن | `IntersectionObserver` + کلاس `reveal` | سبک، روان و بدون وابستگی جدید؛ با `unobserve` بعد از نمایش، هزینهٔ اسکرول صفر می‌شود |
| دسترس‌پذیری حرکت | respect `prefers-reduced-motion` + fallback نمایان | محتوای اصلی هرگز پشت انیمیشن پنهان نمی‌ماند |
| جهت صفحه | `dir="rtl"` روی `<html>` + استفاده از ویژگی‌های منطقی (`inset-inline-start`) | RTL اصیل بدون بازنویسی چیدمان |
| فونت | لینک Google Fonts در `index.html` | نصب سریع، پشتیبانی کامل فارسی، بدون افزودن asset به باندل |
| چیدمان گالری | گرید ۱/۲/۳ ستونه با کارت شاخص دوستونه | حفظ ریتم فضای خالی و نامتقارنی کنترل‌شدهٔ سبک Nordic |

## File Tree Plan

```
app/frontend/
├── DESIGN.md                     # سند طراحی بصری (رنگ، تایپ، فاصله، مدیا)
├── index.html                    # lang=fa, dir=rtl, بارگذاری فونت Vazirmatn
├── tailwind.config.ts            # توکن‌های رنگ سطح/برنز/متن ثانویه + fontFamily
├── image_manifest.json           # خروجی تولید تصاویر
└── src/
    ├── App.tsx                   # روت‌ها (فقط `/` واقعی است)
    ├── index.css                 # متغیرهای تم + کلاس‌های reveal/field/link
    ├── content/site.ts           # برند، ناوبری، پروژه‌ها، اطلاعات تماس
    ├── components/
    │   ├── ArrowLink.tsx
    │   ├── RevealSection.tsx
    │   ├── SiteHeader.tsx
    │   ├── HeroSection.tsx
    │   ├── WelcomeSection.tsx
    │   ├── ShowroomSection.tsx
    │   ├── ContactSection.tsx
    │   └── SiteFooter.tsx
    └── pages/Index.tsx           # چیدمان نهایی لندینگ
```

## Implementation Guide

1. تم: رنگ‌های HSL در `src/index.css` (`--background: 40 43% 97%` ≈ `#FBF9F5`, `--foreground: 0 0% 10%` ≈ `#1A1A1A`) و نگاشت آن‌ها در `tailwind.config.ts` (`surface`, `sand`, `bronze`, `ink-soft`, `ink-faint`).
2. حرکت: هر بخش را در `RevealSection` بپیچید؛ برای پله‌ای شدن، `delay` مضربی از ۹۰ms بدهید. حالت اولیه `opacity: 0; translateY(28px)` است و کلاس `reveal-is-visible` آن را آزاد می‌کند.
3. محتوا: هر متن، تصویر یا لینک جدید را در `src/content/site.ts` اضافه کنید تا از تکرار در کامپوننت‌ها پرهیز شود.
4. هدر: حالت شفاف تا `scrollY > 24`؛ در حالت اسکرول پس‌زمینهٔ کرم و کادر پایین فعال می‌شود. پنل موبایل با Escape بسته و اسکرول بدنه قفل می‌شود.
5. فرم: اعتبارسنجی ساده (نام ≥ ۳ نویسه، تلفن ≥ ۸ رقم با ارقام فارسی/لاتین، توضیح ≥ ۱۰ نویسه) و سپس حالت موفقیت mock. برای اتصال واقعی، این کامپوننت تنها نقطهٔ تغییر است.
6. اعتبارسنجی: در `app/frontend` اجرای `pnpm run lint && pnpm run build`.
