import ContactSection from '@/components/ContactSection';
import HeroSection from '@/components/HeroSection';
import ShowroomSection from '@/components/ShowroomSection';
import SiteFooter from '@/components/SiteFooter';
import SiteHeader from '@/components/SiteHeader';
import WelcomeSection from '@/components/WelcomeSection';

const Index = () => (
  <div className="min-h-screen bg-background">
    <SiteHeader />
    <main>
      <HeroSection />
      <WelcomeSection />
      <ShowroomSection />
      <ContactSection />
    </main>
    <SiteFooter />
  </div>
);

export default Index;
