export interface ShowroomProject {
  title: string;
  category: string;
  image: string;
  /** Wide feature tile spanning two columns on desktop. */
  featured?: boolean;
}

export type SocialChannelKey = 'instagram' | 'whatsapp' | 'roubika' | 'bale';

export interface SocialChannel {
  key: SocialChannelKey;
  label: string;
  handle: string;
  /** Replace the placeholder with the real profile link. */
  href: string;
}

export const siteConfig = {
  brand: 'کارگاه صنایع چوبی عیسی‌پور',
  brandTagline: 'دکوراسیون و کابینت چوبی سفارشی',
  heroTitle: 'کارگاه صنایع چوبی عیسی‌پور',
  heroSubtitle: 'دکوراسیون و کابینت‌های سفارشی، ساختِ دست، برای خانه‌ای که سال‌ها با شما می‌ماند.',
  heroImage: '/images/hero-oak-kitchen.png',
  heroImageMobile: '/images/hero-oak-kitchen-portrait.png',
  welcomeImage: '/images/welcome-oak-cabinet.png',
  phone: '0917 741 8169',
  phoneHref: '+989177418169',
  email: 'hello@choob-khaneh.ir',
  address: 'تهران، خیابان ولی‌عصر، کوچه شهید بهشتی، کارگاه شماره ۷',
  hours: 'شنبه تا پنجشنبه، ۹:۰۰ تا ۱۸:۰۰',
};

export const navLinks = [
  { label: 'ارتباط با ما', href: '#contact' },
  { label: 'درباره ما', href: '#about' },
];

export const socialChannels: SocialChannel[] = [
  { key: 'instagram', label: 'اینستاگرام', handle: 'نمونه‌کارها و ویدیوهای کارگاه', href: '#' },
  { key: 'whatsapp', label: 'واتساپ', handle: '', href: '#' },
  { key: 'roubika', label: 'روبیکا', handle: 'کانال کارگاه و اطلاع‌رسانی', href: '#' },
  { key: 'bale', label: 'بله', handle: 'پیام مستقیم و پیگیری سفارش', href: '#' },
];

export const showroomProjects: ShowroomProject[] = [
  {
    title: 'آشپزخانه بلوط روشن',
    category: 'آشپزخانه',
    image: '/images/showroom-light-oak-kitchen.png',
    featured: true,
  },
  {
    title: 'میز غذاخوری یکپارچه',
    category: 'میز غذاخوری',
    image: '/images/showroom-dining-table.png',
  },
  {
    title: 'کمد دیواری سفارشی',
    category: 'دکوراسیون',
    image: '/images/showroom-oak-shelving.png',
  },
  {
    title: 'دراور چوب گردو',
    category: 'دکوراسیون',
    image: '/images/showroom-wood-dresser.png',
  },
  {
    title: 'جزئیات اتصال دست‌ساز',
    category: 'جزئیات ساخت',
    image: '/images/showroom-craft-detail.png',
  },
  {
    title: 'میز کار کارگاه',
    category: 'کارگاه',
    image: '/images/atmosphere-workshop-bench.png',
  },
];

export const craftPoints = [
  'چوب بلوط و گردوی خشک‌شده در انبار خودمان',
  'اتصالات سنتی و روکش روغن طبیعی بدون رنگ صنعتی',
  'اندازه‌گیری و طراحی اختصاصی بر اساس فضای خانه شما',
];
