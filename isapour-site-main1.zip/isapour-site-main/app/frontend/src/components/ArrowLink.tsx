import type { ReactNode } from 'react';

import { cn } from '@/lib/utils';

interface ArrowLinkProps {
  href: string;
  children: ReactNode;
  variant?: 'solid' | 'outline' | 'light';
  className?: string;
  onClick?: () => void;
}

/** Minimal bordered call-to-action with a left-pointing arrow, matching the RTL reading direction. */
export function ArrowLink({ href, children, variant = 'solid', className, onClick }: ArrowLinkProps) {
  return (
    <a
      href={href}
      onClick={onClick}
      className={cn(
        'group inline-flex min-h-[44px] items-center gap-3 border px-7 py-3 text-[0.85rem] font-medium tracking-[0.12em] transition-colors duration-300',
        variant === 'solid' &&
          'border-foreground bg-foreground text-background hover:bg-transparent hover:text-foreground',
        variant === 'outline' &&
          'border-current bg-transparent text-current hover:bg-foreground hover:text-background hover:border-foreground',
        variant === 'light' &&
          'border-white/70 bg-transparent text-white hover:bg-white hover:text-foreground hover:border-white',
        className,
      )}
    >
      <span>{children}</span>
      <svg
        viewBox="0 0 24 24"
        aria-hidden="true"
        className="h-3.5 w-3.5 transition-transform duration-300 ease-out group-hover:-translate-x-1.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M19 12H5" />
        <path d="m12 19-7-7 7-7" />
      </svg>
    </a>
  );
}

export default ArrowLink;
