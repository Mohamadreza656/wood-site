import { siteConfig } from '@/content/site';

export function HeroSection() {
  return (
    <section id="top" className="hero-shell relative w-full overflow-hidden md:h-screen md:min-h-0">
      <picture>
        <source media="(max-width: 767px)" srcSet={siteConfig.heroImageMobile} />
        <img
          src={siteConfig.heroImage}
          alt="آشپزخانه سفارشی ساخته‌شده از چوب بلوط روشن با نور طبیعی"
          className="hero-shell-image absolute inset-0 h-full w-full object-cover md:object-center"
          fetchPriority="high"
        />
      </picture>
      <div className="absolute inset-0 bg-gradient-to-t from-[rgba(18,16,13,0.8)] via-[rgba(18,16,13,0.32)] to-[rgba(18,16,13,0.42)] md:from-[rgba(18,16,13,0.72)] md:via-[rgba(18,16,13,0.28)] md:to-[rgba(18,16,13,0.45)]" />

      <div className="relative mx-auto flex h-full max-w-[1280px] flex-col justify-end px-5 pb-16 sm:px-6 sm:pb-20 md:px-12 md:pb-28">
        <h1 className="hero-heading max-w-4xl font-light tracking-[-0.01em] text-white md:text-[clamp(2.5rem,6vw,5rem)] md:leading-[1.08]">
          {siteConfig.heroTitle}
        </h1>
        <p className="mt-6 max-w-xl text-[0.95rem] font-light leading-[1.95] text-white/85 sm:text-base md:mt-7 md:text-lg md:leading-[1.9]">
          {siteConfig.heroSubtitle}
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-x-10 gap-y-4 md:mt-10">
          <a
            href="#showroom"
            className="link-underline inline-flex min-h-[44px] items-center text-[0.78rem] font-medium tracking-[0.18em] text-white sm:text-[0.8rem]"
          >
            مشاهده نمونه‌کارها
          </a>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/60 md:flex">
        <span className="text-[0.62rem] tracking-[0.3em]">اسکرول کنید</span>
        <span className="block h-12 w-px bg-white/40" />
      </div>
    </section>
  );
}

export default HeroSection;
