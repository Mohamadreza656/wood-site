import { useEffect, useState } from 'react';

import { navLinks, siteConfig } from '@/content/site';
import { cn } from '@/lib/utils';

export function SiteHeader() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!isMenuOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setIsMenuOpen(false);
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMenuOpen]);

  const isOpaque = isScrolled || isMenuOpen;

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-500',
        isOpaque
          ? 'border-b border-border bg-background/95 text-foreground backdrop-blur'
          : 'border-b border-transparent text-white',
      )}
    >
      <div className="mx-auto flex h-[4.5rem] max-w-[1280px] items-center justify-between gap-4 px-5 sm:gap-6 sm:px-6 md:h-24 md:px-12">
        <a href="#top" className="leading-none" aria-label={siteConfig.brand}>
          <span className="text-[0.9rem] font-light tracking-[0.14em] sm:text-[0.95rem] md:text-lg">
            {siteConfig.brand}
          </span>
        </a>

        <nav className="hidden items-center gap-3 md:flex" aria-label="ناوبری اصلی">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={cn(
                'inline-flex items-center rounded-full border px-5 py-2 text-[0.82rem] font-light tracking-[0.14em] transition-[transform,color,background-color,border-color] duration-300 ease-out hover:scale-105',
                isOpaque
                  ? 'border-border text-foreground hover:border-bronze hover:text-bronze'
                  : 'border-white/45 text-white/95 hover:border-white hover:bg-white/10 hover:text-white',
              )}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <button
          type="button"
          onClick={() => setIsMenuOpen((open) => !open)}
          aria-expanded={isMenuOpen}
          aria-controls="mobile-menu"
          aria-label={isMenuOpen ? 'بستن منو' : 'باز کردن منو'}
          className="flex h-11 w-11 items-center justify-center md:hidden"
        >
          <span className="relative block h-4 w-6" aria-hidden="true">
            <span
              className={cn(
                'absolute left-0 top-0 block h-px w-6 origin-center rounded-full bg-current transition-transform duration-350 ease-out-expo',
                isMenuOpen && 'translate-y-[7.5px] rotate-45',
              )}
            />
            <span
              className={cn(
                'absolute left-0 top-[7.5px] block h-px w-6 rounded-full bg-current transition-opacity duration-200 ease-out',
                isMenuOpen && 'opacity-0',
              )}
            />
            <span
              className={cn(
                'absolute left-0 top-[15px] block h-px w-6 origin-center rounded-full bg-current transition-transform duration-350 ease-out-expo',
                isMenuOpen && '-translate-y-[7.5px] -rotate-45',
              )}
            />
          </span>
        </button>
      </div>

      <div
        id="mobile-menu"
        className={cn(
          'overflow-hidden border-border bg-background text-foreground transition-[max-height,opacity] duration-500 md:hidden',
          isMenuOpen ? 'max-h-96 border-t opacity-100' : 'max-h-0 opacity-0',
        )}
      >
        <nav className="mx-auto flex max-w-[1280px] flex-col gap-3 px-5 py-6 sm:px-6" aria-label="ناوبری موبایل">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setIsMenuOpen(false)}
              className="inline-flex w-fit items-center rounded-full border border-border px-6 py-3 text-base font-light tracking-[0.16em] transition-[transform,color,border-color] duration-300 ease-out hover:scale-105 hover:border-bronze hover:text-bronze"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}

export default SiteHeader;
