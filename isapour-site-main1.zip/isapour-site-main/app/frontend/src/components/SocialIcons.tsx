import type { SVGProps } from 'react';

import type { SocialChannelKey } from '@/content/site';

type IconProps = SVGProps<SVGSVGElement>;

const baseProps = {
  viewBox: '0 0 24 24',
  'aria-hidden': true,
  focusable: false,
  className: 'h-6 w-6',
} as const;

export function InstagramIcon(props: IconProps) {
  return (
    <svg {...baseProps} fill="none" stroke="currentColor" strokeWidth={1.4} {...props}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.1" cy="6.9" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function WhatsAppIcon(props: IconProps) {
  return (
    <svg {...baseProps} fill="currentColor" {...props}>
      <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.23-.64.08-.3-.15-1.26-.47-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.35-.35.52-.53.17-.17.23-.3.35-.5.11-.2.06-.37-.03-.52-.09-.15-.66-1.59-.9-2.18-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.11.57-.08 1.76-.72 2-1.41.25-.7.25-1.29.18-1.42-.08-.12-.28-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.89 9.89-9.89 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 6.99c0 5.45-4.44 9.89-9.88 9.89m8.41-18.3A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.69 1.45h.005c6.554 0 11.89-5.34 11.893-11.9a11.82 11.82 0 0 0-3.48-8.41" />
    </svg>
  );
}

export function RoubikaIcon(props: IconProps) {
  return (
    <svg {...baseProps} fill="none" stroke="currentColor" strokeWidth={1.4} {...props}>
      <path d="M20 11.6c0 4.2-3.6 7.6-8 7.6-.9 0-1.8-.15-2.6-.42L4 20.4l1.3-3.3A7.4 7.4 0 0 1 4 11.6C4 7.4 7.6 4 12 4s8 3.4 8 7.6Z" />
      <path d="M8.8 11.6h6.4M8.8 14.4h4" />
    </svg>
  );
}

export function BaleIcon(props: IconProps) {
  return (
    <svg {...baseProps} fill="none" stroke="currentColor" strokeWidth={1.4} {...props}>
      <path d="M20.5 4.2 3.6 11.1l5.2 1.9 1.8 5.6 3.2-7.4 6.7-7Z" />
      <path d="M8.8 13 20.5 4.2" />
    </svg>
  );
}

export const socialIcons: Record<SocialChannelKey, (props: IconProps) => JSX.Element> = {
  instagram: InstagramIcon,
  whatsapp: WhatsAppIcon,
  roubika: RoubikaIcon,
  bale: BaleIcon,
};
