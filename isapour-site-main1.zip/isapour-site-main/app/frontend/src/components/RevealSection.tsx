import { useEffect, useRef, useState, type ElementType, type ReactNode } from 'react';

import { cn } from '@/lib/utils';

interface RevealSectionProps {
  children: ReactNode;
  className?: string;
  /** Delay in milliseconds before the reveal transition starts. */
  delay?: number;
  as?: ElementType;
  id?: string;
  'aria-labelledby'?: string;
}

/**
 * Reveals its children with a soft fade-in-up transition once they scroll into view.
 * Falls back to an immediately visible state when IntersectionObserver is unavailable
 * or the visitor prefers reduced motion, so content is never trapped at opacity 0.
 */
export function RevealSection({
  children,
  className,
  delay = 0,
  as: Component = 'div',
  ...rest
}: RevealSectionProps) {
  const elementRef = useRef<HTMLElement | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const node = elementRef.current;

    const prefersReducedMotion =
      typeof window.matchMedia === 'function' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!node || typeof IntersectionObserver === 'undefined' || prefersReducedMotion) {
      setIsVisible(true);
      return;
    }

    const rect = node.getBoundingClientRect();
    const isAboveTheFold = rect.bottom <= 0;
    const isInsideInitialViewport = rect.top < window.innerHeight;

    // Anything already rendered inside the current viewport stays visible from the first
    // paint, so content is never hidden when the observer cannot observe a scroll change.
    if (isAboveTheFold || isInsideInitialViewport) {
      setIsVisible(true);
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' },
    );

    observer.observe(node);

    // Safety net: the section fades in on its own shortly after mount even without a
    // scroll event, so content is never stuck at opacity 0 in any environment.
    const fallbackTimer = window.setTimeout(() => setIsVisible(true), 600 + delay);

    return () => {
      observer.disconnect();
      window.clearTimeout(fallbackTimer);
    };
  }, [delay]);

  return (
    <Component
      ref={elementRef}
      className={cn('reveal', isVisible && 'reveal-is-visible', className)}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
      {...rest}
    >
      {children}
    </Component>
  );
}

export default RevealSection;
