import ArrowLink from '@/components/ArrowLink';
import RevealSection from '@/components/RevealSection';
import { craftPoints, siteConfig } from '@/content/site';

export function WelcomeSection() {
  return (
    <section id="about" className="mx-auto max-w-[1280px] px-6 py-24 md:px-12 md:py-36 lg:py-44">
      <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-24">
        <RevealSection className="order-1 lg:order-1">
          <p className="label-eyebrow text-bronze">درباره ما</p>
          <h2 className="mt-6 text-[clamp(1.9rem,3.6vw,3.25rem)] font-light leading-[1.15] tracking-[-0.005em]">
          کابینت، کمد و مصنوعات چوبی سفارشی
          </h2>
          <div className="mt-8 space-y-6 text-base font-light leading-[1.9] text-ink-soft md:text-[1.05rem]">
            <p>
              هر قطعه‌ای که از کارگاه ما بیرون می‌آید، از یک تختهٔ چوب خام آغاز می‌شود که خودمان انتخابش
              می‌کنیم؛ بلوط و گردوی خشک‌شده‌ای که سال‌ها در انبار کارگاه آرام گرفته تا دیگر تکان نخورد. کیفیت
              چوب برای ما یک عدد روی کاغذ نیست، بلکه رگه‌ها، بافت و بویی است که سال‌ها با شما در خانه می‌ماند.
            </p>
            <p>
              ساخت با دست انجام می‌شود: اندازه‌گیری دقیق فضای شما، اتصالات سنتی، سنباده‌زنی لایه‌به‌لایه و
              پرداخت با روغن طبیعی، بدون رنگ‌های صنعتی. نتیجه، کابینت و دکوراسیونی است که بی‌سروصدا با زندگی
              شما هم‌شکل می‌شود.
            </p>
          </div>

          <ul className="mt-10 space-y-4 border-t border-border pt-8">
            {craftPoints.map((point) => (
              <li key={point} className="flex items-start gap-4 text-[0.95rem] font-light text-ink-soft">
                <span className="mt-[0.65rem] block h-px w-6 shrink-0 bg-sand" />
                <span>{point}</span>
              </li>
            ))}
          </ul>

          <div className="mt-12">
            <ArrowLink href="#showroom">دیدن شوروم</ArrowLink>
          </div>
        </RevealSection>

        <RevealSection className="order-2 lg:order-2" delay={140}>
          <div className="overflow-hidden">
            <img
              src={siteConfig.welcomeImage}
              alt="کمد دیواری سفارشی از چوب بلوط روشن در فضایی مینیمال"
              loading="lazy"
              className="aspect-[4/5] w-full object-cover transition-transform [transition-duration:1200ms] ease-out hover:scale-[1.03]"
            />
          </div>
          <p className="mt-5 text-[0.78rem] font-light tracking-[0.14em] text-ink-faint">
            کمد بلوط سفارشی — پروژهٔ مسکونی، تهران
          </p>
        </RevealSection>
      </div>
    </section>
  );
}

export default WelcomeSection;
