import RevealSection from '@/components/RevealSection';
import { socialIcons } from '@/components/SocialIcons';
import { siteConfig, socialChannels } from '@/content/site';

// استایل اختصاصی و رنگ‌بندی برندها
const channelStyles: Record<
  string,
  {
    badgeClass: string;
    hoverBorder: string;
    ctaText: string;
  }
> = {
  instagram: {
    badgeClass: 'bg-rose-500/10 text-rose-600 group-hover:bg-rose-600 group-hover:text-white',
    hoverBorder: 'hover:border-rose-300 hover:shadow-rose-500/10',
    ctaText: 'مشاهده پیج',
  },
  whatsapp: {
    badgeClass: 'bg-emerald-500/10 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white',
    hoverBorder: 'hover:border-emerald-300 hover:shadow-emerald-500/10',
    ctaText: 'شروع گفتگو',
  },
  rubika: {
    badgeClass: 'bg-purple-500/10 text-purple-600 group-hover:bg-purple-600 group-hover:text-white',
    hoverBorder: 'hover:border-purple-300 hover:shadow-purple-500/10',
    ctaText: 'عضویت در کانال',
  },
  roubika: {
    badgeClass: 'bg-purple-500/10 text-purple-600 group-hover:bg-purple-600 group-hover:text-white',
    hoverBorder: 'hover:border-purple-300 hover:shadow-purple-500/10',
    ctaText: 'عضویت در کانال',
  },
  bale: {
    badgeClass: 'bg-emerald-500/10 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white',
    hoverBorder: 'hover:border-emerald-300 hover:shadow-emerald-500/10',
    ctaText: 'ارسال پیام',
  },
};

export function ContactSection() {
  return (
    <section id="contact" className="border-t border-border">
      <div className="mx-auto max-w-[1280px] px-6 py-24 md:px-12 md:py-36 lg:py-44">
        <RevealSection>
          <p className="label-eyebrow text-bronze">تماس</p>
          <h2 className="mt-6 max-w-2xl text-[clamp(1.9rem,3.6vw,3.25rem)] font-light leading-[1.15]">
            راه‌های ارتباطی
          </h2>
          <p className="mt-7 max-w-md text-base font-light leading-[1.9] text-ink-soft">
            می‌توانید از هر کانالی که راحت‌ترید با ما در تماس باشید؛
          </p>
        </RevealSection>

        <div className="mt-16 grid grid-cols-1 gap-4 sm:grid-cols-2 md:mt-20 md:gap-6 lg:grid-cols-4">
          {socialChannels.map((channel, index) => {
            const Icon = socialIcons[channel.key];
            const style = channelStyles[channel.key] || {
              badgeClass: 'bg-bronze/10 text-bronze group-hover:bg-bronze group-hover:text-white',
              hoverBorder: 'hover:border-bronze hover:shadow-bronze/10',
              ctaText: 'ارتباط',
            };

            return (
              <RevealSection key={channel.key} delay={index * 90}>
                <a
                  href={channel.href}
                  aria-label={channel.label}
                  className={`group flex min-h-[210px] flex-col justify-between rounded-2xl border border-border bg-background p-7 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl ${style.hoverBorder}`}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className={`flex h-12 w-12 items-center justify-center rounded-xl transition-colors duration-300 ${style.badgeClass}`}
                    >
                      {Icon ? (
                        <Icon className="h-6 w-6 transition-transform duration-300 group-hover:scale-110" />
                      ) : (
                        <span className="text-xs font-bold">{channel.label.slice(0, 2)}</span>
                      )}
                    </div>
                    <span className="text-[0.8rem] font-medium text-ink-faint transition-colors duration-300 group-hover:text-ink">
                      {style.ctaText} &larr;
                    </span>
                  </div>

                  <div className="mt-8">
                    <span className="block text-[1.1rem] font-medium transition-colors duration-300 group-hover:text-bronze">
                      {channel.label}
                    </span>
                    {channel.handle ? (
                      <span className="mt-2 block text-[0.85rem] font-light leading-[1.7] text-ink-faint">
                        {channel.handle}
                      </span>
                    ) : null}
                  </div>
                </a>
              </RevealSection>
            );
          })}
        </div>

        <RevealSection delay={180}>
          <dl className="mt-20 grid gap-10 border-t border-border pt-12 text-[0.95rem] font-light sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <dt className="label-eyebrow text-ink-faint">تلفن</dt>
              <dd className="mt-3">
                <a
                  href={`tel:${siteConfig.phoneHref}`}
                  dir="ltr"
                  className="link-underline inline-block tracking-[0.08em] text-ink-soft"
                >
                  {siteConfig.phone}
                </a>
              </dd>
            </div>
            <div>
              <dt className="label-eyebrow text-ink-faint">نشانی کارگاه</dt>
              <dd className="mt-3 leading-[1.9] text-ink-soft">{siteConfig.address}</dd>
            </div>
            <div>
              <dt className="label-eyebrow text-ink-faint">ساعات کاری</dt>
              <dd className="mt-3 leading-[1.9] text-ink-soft">{siteConfig.hours}</dd>
            </div>
          </dl>
        </RevealSection>
      </div>
    </section>
  );
}

export default ContactSection;