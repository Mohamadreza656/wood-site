import { navLinks, siteConfig } from '@/content/site';

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-surface/60">
      <div className="mx-auto max-w-[1280px] px-6 py-16 md:px-12 md:py-20">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-base font-light tracking-[0.14em]">{siteConfig.brand}</p>
            <p className="mt-4 text-[0.82rem] font-light leading-[1.9] text-ink-faint">
              {siteConfig.brandTagline}
            </p>
          </div>

          <nav className="flex flex-col gap-4 text-[0.9rem] font-light text-ink-soft" aria-label="ناوبری فوتر">
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} className="link-underline w-fit">
                {link.label}
              </a>
            ))}
          </nav>

          <div className="text-[0.9rem] font-light text-ink-soft">
            <a href={`tel:${siteConfig.phoneHref}`} dir="ltr" className="link-underline">
              {siteConfig.phone}
            </a>
            <p className="mt-4 leading-[1.9] text-ink-faint">{siteConfig.address}</p>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-border pt-8 text-[0.75rem] font-light text-ink-faint sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} {siteConfig.brand} — تمام حقوق محفوظ است.</span>
        </div>
      </div>
    </footer>
  );
}

export default SiteFooter;
