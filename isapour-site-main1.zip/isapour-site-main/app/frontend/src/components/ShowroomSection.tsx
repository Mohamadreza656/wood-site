import RevealSection from '@/components/RevealSection';
import { showroomProjects } from '@/content/site';
import { cn } from '@/lib/utils';

export function ShowroomSection() {
  return (
    <section id="showroom" className="border-t border-border bg-surface/60">
      <div className="mx-auto max-w-[1280px] px-6 py-24 md:px-12 md:py-36 lg:py-44">
        <RevealSection className="max-w-2xl">
          <h2 className="text-[clamp(1.9rem,3.6vw,3.25rem)] font-light leading-[1.15]">
            پروژه‌های ساخته‌شده
          </h2>
          <p className="mt-7 text-base font-light leading-[1.9] text-ink-soft md:text-[1.05rem]">
            گزیده‌ای از آشپزخانه‌ها، میزهای غذاخوری و دکوراسیون سفارشی که در کارگاه ما ساخته و در خانه‌های
            مشتریان نصب شده‌اند.
          </p>
        </RevealSection>

        <div className="mt-16 grid grid-cols-1 gap-4 sm:grid-cols-2 md:mt-24 md:gap-8 lg:grid-cols-3">
          {showroomProjects.map((project, index) => (
            <RevealSection
              key={project.title}
              delay={index < 3 ? index * 90 : (index % 3) * 90}
              className={cn(project.featured && 'sm:col-span-2')}
            >
              <a href="#contact" className="group block">
                <div className="overflow-hidden bg-border">
                  <img
                    src={project.image}
                    alt={`${project.title} — ${project.category}`}
                    loading="lazy"
                    className={cn(
                      'w-full object-cover transition-transform [transition-duration:900ms] ease-out group-hover:scale-[1.04]',
                      project.featured ? 'aspect-[16/10]' : 'aspect-[4/3]',
                    )}
                  />
                </div>
                <div className="mt-5 flex items-baseline justify-between gap-4 border-t border-border pt-4">
                  <h3 className="text-[1.02rem] font-light tracking-[0.02em] transition-colors duration-300 group-hover:text-bronze">
                    {project.title}
                  </h3>
                  <span className="shrink-0 text-[0.72rem] font-light tracking-[0.18em] text-ink-faint">
                    {project.category}
                  </span>
                </div>
              </a>
            </RevealSection>
          ))}
        </div>
      </div>
    </section>
  );
}

export default ShowroomSection;
